import React, {Component} from 'react';

export default class ContactForm extends Component {
    constructor(props) {
        super(props);

        this.onChangeFullName = this.onChangeFullName.bind(this);
        this.onChangeEmailAddress = this.onChangeEmailAddress.bind(this);
        this.onChangeMessage = this.onChangeMessage.bind(this);
        this.onSubmit = this.onSubmit.bind(this);

        this.state = {
            full_name: '',
            email_address: '',
            message: ''
        }
    }

    onChangeFullName(e) {
        this.setState({
            full_name: e.target.value
        });
    }
    
    onChangeEmailAddress(e) {
        this.setState({
            email_address: e.target.value
        });
    }

    onChangeMessage(e) {
        this.setState({
            message: e.target.value
        });
    }

    onSubmit (e) {
        e.preventDefault();

        console.log(`Form submitted: `);
        console.log(`Full Name ${this.state.full_name}`);
        console.log(`Email Address: ${this.state.email_address}`);
        console.log(`Message    : ${this.state.message}`);
    
        this.setState ({
            full_name: '',
            email_address: '',
            message: ''
        })
    }

    render() {
        return(
            <div style={{marginTop: 20}}>
                <h3>Contact Us</h3>
                <form onSubmit={this.onSubmit}>
                    <div className="form-group">
                        <label>Full Name </label>
                        <input type="text"
                                className="form-control"
                                value={this.state.full_name}
                                onChange={this.onChangeFullName}
                                />
                        </div> 
                        <div className="form-group">
                        <label>Email Address: </label>
                        <input type="email"
                                className="form-control"
                                value={this.state.email_address}
                                onChange={this.onChangeEmailAddress}
                                />
                        </div> 
                        <div className="form-group">
                        <label>Write your message here: </label>
                        <input type="textarea" row= {3}
                                className="form-control"
                                value={this.state.message}
                                onChange={this.onChangeMessage}
                                />
                        
                        </div> 
                        <div className="form-group">
                                <input type="submit" value="Submit" className="btn btn-primary" />
                        </div>
                </form>
            </div>
        )
    }
    }    
